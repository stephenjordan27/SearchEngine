//import java.io.File;
//
//public class Main{
//	public static void main(String[] args){
//		//hanya contoh, sesuaikan dengan letak dataset di komputer anda
//		File inputDir = new File("F:/SEMESTER 7 GANJIL 2019-2020/Pencarian dan Temu Kembali Informasi/YouRSearchEngine/raw_dataset");
//		File outputDir = new File("F:/SEMESTER 7 GANJIL 2019-2020/Pencarian dan Temu Kembali Informasi/YouRSearchEngine/preprocessed_dataset");
//		
//		Preprocessor p =new Preprocessor();
//		long startTime = System.currentTimeMillis();
//			
//		p.preProcess(inputDir,outputDir);
//			
//		long endTime = System.currentTimeMillis();
//		
//		System.out.println();
//		System.out.println("Time ellapsed: "+(endTime-startTime));
//	}
//}